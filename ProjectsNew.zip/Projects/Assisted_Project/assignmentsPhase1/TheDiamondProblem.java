package assignmentsPhase1;
interface AssistedProject{
	default void showMethod(){
		System.out.println("I am doing assisted projects!");
	}
}
interface PracticeProject{
	default void showMethod(){
		System.out.println("I am doing practice project too!");
	}
}

public class TheDiamondProblem implements AssistedProject,PracticeProject{
	@Override
	public void showMethod() {
		
		AssistedProject.super.showMethod();
		PracticeProject.super.showMethod();
	}
	public static void main(String[] args) {
		TheDiamondProblem obj=new TheDiamondProblem();
		obj.showMethod();
		
	}

}
