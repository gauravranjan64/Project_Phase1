package assignmentsPhase1;
class MyThread extends Thread{
	public void run(){
		System.out.println("This is my thread using Thread Class!");
	}
}
class MyThread1 implements Runnable{

	@Override
	public void run() {
		System.out.println("This is my thread using Runnable interface!");
		
	}
	
}
public class ThreadAssignment {

	public static void main(String[] args) {
		MyThread obj=new MyThread();
		obj.start();
		MyThread1 obj1=new MyThread1();
		Thread t=new Thread(obj1);
		t.start();

	}

}
