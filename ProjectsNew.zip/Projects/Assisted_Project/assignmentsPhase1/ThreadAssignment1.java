package assignmentsPhase1;
class SleepThread extends Thread{
	public void run(){
		int sum=0;
		System.out.println("Sum: "+sum);
		for(int i=0;i<3;i++){
			
			try{
				Thread.sleep(2000);
				
			}catch(Exception e){	
				System.out.println(e);
			}
			sum=sum+10;
			System.out.println("New sum: "+(sum));
		}
	}
}
public class ThreadAssignment1 {

	public static void main(String[] args) throws InterruptedException {
		SleepThread obj=new SleepThread();
		obj.start();
		
	}

}
