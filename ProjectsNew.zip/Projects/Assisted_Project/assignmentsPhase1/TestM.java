package assignmentsPhase1;

public class TestM {
	int age=56;
	public long a=6958L;
	private int b=25;
	protected float c=2.34f;
	
	public void publicMethod(){
		System.out.println("Public method of class M");
	}
	protected void protectedMethod(){
		System.out.println("Protected method of class M");
	}
	private void privateMethod(){
		System.out.println("Private method of class M");
	}
	 void defaultMethod(){
		System.out.println("Default method of class M");
	}
}
