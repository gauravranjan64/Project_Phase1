package assignmentsPhase1;
class MyThreadExample extends Thread{
	synchronized public void run(){
		System.out.println("In the run method of MyThreadExample");
		synchronized(this){
			System.out.println("In synchronized block of run method");
		}
	}
	public void normalmethod(){
		System.out.println("In the normal method");
		synchronized(this){
			System.out.println("Synchronized block in normal method!!");
		}
	}
	
}
public class ThreadSynchronized {

	public static void main(String[] args) {
		MyThreadExample obj=new MyThreadExample();
		obj.start();
		obj.normalmethod();
		
	}

}
