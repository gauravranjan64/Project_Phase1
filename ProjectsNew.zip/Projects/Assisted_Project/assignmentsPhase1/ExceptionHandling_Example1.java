package assignmentsPhase1;

import java.io.IOException;
import java.util.*;

public class ExceptionHandling_Example1 {
	
	int display(int l,int b) throws IOException{
		if(l>b){
			throw new IOException("Length is greater than breadth");
		}else{
			System.out.println("Both parameters are fine"+"\n"+"Area: "+(l*b));
		}
		return l*b;
	}
	public static void main(String[] args)  {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter length and Breadth: ");
		int l=sc.nextInt();
		int b=sc.nextInt();
		ExceptionHandling_Example1 obj=new ExceptionHandling_Example1();
		try{
			obj.display(l, b);
		}catch(Exception e){
			System.out.println("Length is greater than breadth!");
		}finally{
			System.out.println("Finaaly need to be printed");
		}
		

	}

}
