package assignmentsPhase1;

public class ExceptionHandling_Example {

	public static void main(String[] args) {
		int num1=20;
		int num2=0;
		int num3;
		try{
			num3=num1/num2;
			System.out.println("Result: "+num3);
		}
		catch(ArithmeticException ae){
			System.out.println("Number divided by zero");
			System.out.println(ae.getMessage());
			System.out.println("If the exception is caught correctly then child exception displays");
		}
		catch(Exception e){
			System.out.println("I am the parent class Exception!!");
		}
		finally{
			System.out.println("Addition of "+num1+" and"+num2+" is "+(num1+num2));
			System.out.println("Finally block always gets executed!!");
		}

	}

}
