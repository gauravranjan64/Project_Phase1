package assignmentsPhase1;

abstract class Vehicle{
	int speed=40;
	long distance=1200;
	abstract void  run();
	abstract void stop();
	public void fuel(int n){
		System.out.println("Fuel integer parameter: "+n);
	}
	public void fuel(float a, String s){
		System.out.println("Fuel float and string parameter: "+a+" "+s);
	}
	public void fuel(char c,int b){
		System.out.println("Fuel char and integer parameter: "+c+" "+b);
	}
	Vehicle(){
		System.out.println("Default constructor of Vehicle class!");
		System.out.println("Speed: "+speed+" "+"Distance: "+distance);
	}
	Vehicle(int speed,long distance){
		
		System.out.println("Parameterized constructor of Vehicle class!");
//		System.out.println("Speed: "+speed);
//		System.out.println("Distance: "+distance);
		
	}
	void display(){
		System.out.println("Speed: "+speed+"Distance: "+distance);
	}
}
class TwoWheeler extends Vehicle{
	int nos_of_tyers=2;
	int speed=120;
	long distance=3000;
	void run(){
		System.out.println("Run Method");
	}
	void stop(){
		System.out.println("Stop Method");
	}
	TwoWheeler(){
		System.out.println("Inside Default constrauctor of TwoWheeler class");
		
	}
	void display(){
		System.out.println("Speed: "+speed+" "+"Sistance: "+distance);
	}
}
public class OopsExample {

	public static void main(String[] args) {
		Vehicle obj=new TwoWheeler();
		obj.display();
		obj.fuel(6);
		obj.fuel('P', 32);
		obj.fuel(23.1f, "Petrol");
		obj.run();
		obj.stop();

	}

}
