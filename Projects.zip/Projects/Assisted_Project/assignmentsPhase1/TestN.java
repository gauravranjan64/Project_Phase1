package assignmentsPhase1;

public class TestN {
	int age=56;
	public long a=639L;
	private int b=258;
	protected float c=458.34f;
	
	public void publicMethod(){
		System.out.println("Public method of class N");
	}
	protected void protectedMethod(){
		System.out.println("Protected method of class N");
	}
	private void privateMethod(){
		System.out.println("Private method of class N");
	}
	 void defaultMethod(){
		System.out.println("Default method of class N");
	}
}
